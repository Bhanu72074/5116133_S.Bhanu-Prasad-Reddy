import java.util.*;

class Customer {
    private String name;
    private String customerId;
    private double unitsConsumed;

    public Customer(String name, String customerId, double unitsConsumed) {
        this.name = name;
        this.customerId = customerId;
        this.unitsConsumed = unitsConsumed;
    }

    public String getName() {
        return name;
    }

    public String getCustomerId() {
        return customerId;
    }

    public double getUnitsConsumed() {
        return unitsConsumed;
    }
}

class Bill {
    private Customer customer;
    private double totalAmount;

    public Bill(Customer customer) {
        this.customer = customer;
        this.totalAmount = calculateBill(customer.getUnitsConsumed());
    }

    // Bill calculation logic
    private double calculateBill(double units) {
        double amount = 0;

        if (units <= 100) {
            amount = units * 1.5;
        } else if (units <= 200) {
            amount = (100 * 1.5) + (units - 100) * 2.5;
        } else if (units <= 300) {
            amount = (100 * 1.5) + (100 * 2.5) + (units - 200) * 4.0;
        } else {
            amount = (100 * 1.5) + (100 * 2.5) + (100 * 4.0) + (units - 300) * 5.0;
        }

        // Add a fixed charge
        amount += 50;
        return amount;
    }

    public void displayBill() {
        System.out.println("--------------------------------------------------");
        System.out.println("               ELECTRICITY BILL                   ");
        System.out.println("--------------------------------------------------");
        System.out.println("Customer Name     : " + customer.getName());
        System.out.println("Customer ID       : " + customer.getCustomerId());
        System.out.println("Units Consumed    : " + customer.getUnitsConsumed());
        System.out.println("--------------------------------------------------");
        System.out.printf("Total Amount (₹)  : %.2f\n", totalAmount);
        System.out.println("--------------------------------------------------");
    }
}

public class ElectricityBillingSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("===== Electricity Billing System =====");
        try {
            System.out.print("Enter Customer Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Customer ID: ");
            String id = sc.nextLine();

            System.out.print("Enter Units Consumed: ");
            double units = sc.nextDouble();

            // Input validation
            if (units < 0) {
                System.out.println("Error: Units consumed cannot be negative.");
                return;
            }

            Customer customer = new Customer(name, id, units);
            Bill bill = new Bill(customer);
            bill.displayBill();

        } catch (InputMismatchException e) {
            System.out.println("Error: Please enter valid numeric input for units.");
        } finally {
            sc.close();
        }
    }
}